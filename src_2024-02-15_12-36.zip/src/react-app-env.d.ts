/// <reference types='react-scripts' />
declare module 'stompjs'
declare module 'react-stomp'
declare module 'sockjs-client'