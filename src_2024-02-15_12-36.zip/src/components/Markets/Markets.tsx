import React, { useCallback, useEffect, useState } from 'react';
import './Markets.scss';
import { Calculator } from '../Calculator';
import { CalculatorButtonType } from '../../types/enums';
import { CustomSelect } from '../CustomSelect';
import classNames from 'classnames';
import { toast } from 'react-toastify';
import { client } from '../../api/fetchClient';
import { Stack } from 'react-bootstrap';
import { MarketsSpotType } from '../../types/types';
import SockJS from 'sockjs-client';
import Stomp from 'stompjs';
import { capitalizeFirstLetter } from '../../helpers';

export const Markets = () => {
  const [markets, setMarkets] = useState<string[]>([]);
  const [currentMarket, setcurrentMarket] = useState('BINANCE');
  const [symbols, setSymbols] = useState<string[]>([]);
  const [currentSymbol, setCurrentSymbol] = useState('');
  const [symbolPrice, setSymbolPrice] = useState(0);
  const [counterEarning, setCounterEarning] = useState(true);
  const [tradingVariation, setTradingVariation] = useState('spot');

  const websocketUrl = '/websocket-url';

  const counterEarningIndex = counterEarning ? 0 : 1;
  const tradingVariationArray = [tradingVariation, 'futures', 'inverse'];

  const getMarketsData = useCallback(async (url = '') => {
    try {
      const loadedData = await client.get<MarketsSpotType>('/api/markets/spot' + url);
      const { markets, market, symbols, symbol, counterEarning, tradingVariation } = loadedData.body;

      setMarkets([...markets, 'BYBIT', 'COINBASE']);
      setcurrentMarket(market);
      setSymbols(symbols);
      setCurrentSymbol(symbol);
      setCounterEarning(counterEarning);
      setTradingVariation(tradingVariation)
    } catch (error) {
      toast.error(`${error}`);
    }
  }, []);

  const handleCurrentSymbolChange = async (index: number) => {
    if (counterEarningIndex !== index) {
      await getMarketsData(`/${currentMarket}/${currentSymbol}?counterEarning=${!counterEarning}`);
    }
  };

  const handleSymbolsChange = async (symbol: string) => {
    setSymbolPrice(() => 0);
    await getMarketsData(`/${currentMarket}/${symbol}?counterEarning=${counterEarning}`);
  };

  useEffect(() => {
    getMarketsData();
  }, [getMarketsData]);

  useEffect(() => {
    const socket = new SockJS(websocketUrl);
    const stompClient = Stomp.over(socket);
    stompClient.debug = null;
    let isConnected = false;

    const connectMarketPriceWebsocket = (stompClient: any, sessionId: string) => {
      stompClient.subscribe(`/user/${sessionId}/market-price`, (message:any) => {
          const marketMessage = JSON.parse(message.body);
          setSymbolPrice(() => marketMessage.price);
      });
    };

    const handleSocketClose = () => {
      if (isConnected) {
        stompClient.disconnect();
        toast.info('Socket connection closed');
      }
    };

    const websocketMarketPrice = () => {
      stompClient.connect({ symbol: currentSymbol, market: currentMarket }, (frame: any) => {
        isConnected = true;
        const userName = frame.headers['user-name'];
        toast.success('Socket connected');
  
        const subscription = stompClient.subscribe(`/user/${userName}/web-id`, (message: any) => {
          subscription.unsubscribe();
          connectMarketPriceWebsocket(stompClient, message.body);
        });
  
        stompClient.send('/app/init-web-id', {}, JSON.stringify({ userName, symbol: currentSymbol }));
      }, (message: any) => {
        if (message.startsWith('Whoops! Lost connection to')) {
          toast.error('Socket lost. Reload this page');
        } else {
          toast.error(`Socket lost. Error: ${message}`);
        }
      });

      return () => {
        handleSocketClose();
      };
    };

    websocketMarketPrice();

    return () => {
      handleSocketClose();
    };
  }, [currentSymbol, currentMarket]);

  return (
    <main className='px-3 px-md-5' style={{maxWidth: '1600px', margin: '0 auto'}}>
      <Stack direction="horizontal" gap={3} className='justify-content-between'>
        <div className='header__left'>
          <div>
            {tradingVariationArray.map((tradeVar, index) =>
              <span key={index} className={classNames('header__button', {
                active: tradeVar === currentSymbol,
              })} >{capitalizeFirstLetter(tradeVar)}</span>
            )}
          </div>

          <div>
            {markets.map((market, index) =>
              <span key={index} className={classNames('header__button', {
                active: market === currentMarket,
              })} onClick={() => setcurrentMarket(market)}>{capitalizeFirstLetter(market)}</span>
            )}
          </div>



        </div>
        <Stack direction="horizontal" gap={3} className='justify-content-between py-3'>
          <CustomSelect data={['Split position','Choose average','Average All']} title={'Average '} />
          <CustomSelect data={symbols} title={currentSymbol} handler={handleSymbolsChange} isSymbols />
        </Stack>
      </Stack>

      {/* <div className='markets'> */}
        <div className='markets__calculators'>
            <Calculator currency='USDT' type={CalculatorButtonType.buy} marketPrice={symbolPrice} />
            <Calculator currency='USDT' type={CalculatorButtonType.sell} marketPrice={symbolPrice} />
        {/* </div> */}

        {/* <div className='d-flex flex-column justify-content-between gap-3'> */}
        <Stack direction="vertical" gap={3}>
          <div className='markets__marketprice earn'>
            Choose your earn:

            <ul className='markets__options'>
              {currentSymbol.split('_').map((symbol, index) =>
                <li key={symbol} style={{cursor: 'pointer'}} className={classNames('header__button', {
                  active: counterEarningIndex === index,
                })} onClick={() => handleCurrentSymbolChange(index)}>{symbol} - {index}</li>
              )}
            </ul>
          </div>

          <div className='markets__marketprice'>
            Market price:
            <p className='markets__marketprice-value'>{symbolPrice}</p>
          </div>
        {/* </div> */}
        </Stack>
      </div>
    </main>
  );
};